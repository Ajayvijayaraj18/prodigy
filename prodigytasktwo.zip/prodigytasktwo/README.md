# Stopwatch-Project
A simple stopwatch program using HTML CSS and JavaScript!
